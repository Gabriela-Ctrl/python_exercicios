print(" ")
print("Lista dos Estados")
print(" ")

estados = ["São Paulo", "Rio de Janeiro", "Espirito Santo", "Minas Gerais"]

# Listar usando laço
for i, estado in enumerate(estados, 1):
    print(f"{i} - {estado}")