print("")
print("======== TIMES ========")
print("")

times = ["Corinrhians", "São Paulo", "Flamengo", "Vasco"]

# Lista usando laço
for time in times:
    print(time)