nota = int(input("Insira sua nota: "))

if nota >= 5: 
    print("Aprovado")
else:
    print("Reprovado")