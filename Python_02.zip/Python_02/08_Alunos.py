print("=====ALUNOS=====")
print(" ")

# Array das lojas 
nomes = ["Gabriela", "Sophia", "Raphael", "Ignacio", "Victor"]

# Exibindo Lojas
for i, nomes in enumerate(nomes,1):
    print(f"{i} = {nomes}")
    print(" ")