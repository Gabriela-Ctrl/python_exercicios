nome = input("Insira seu nome: ")
senha = input("Insire sua senha: ")

if nome == "admin" and senha == "1234":
    print("Sucesso!")
else:
    print("Usuário ou Senha incorretos")