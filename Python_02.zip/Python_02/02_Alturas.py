print("===Altura em CM===")

# alturas
altura1 = input("Informe a altura da pessoa 1: ")
altura2 = input("Informe a altura pessoa 2: ")

# Sistema de comparação
if altura1 > altura2:
    print("A pessoa 1 é mais alta")
else:
    print("A pessoa 2 é mais alta")